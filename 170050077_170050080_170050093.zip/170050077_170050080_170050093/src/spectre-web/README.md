## Running the Files
```shell
$ cd l1cache-timer
$ make
$ cd ../webpage
$ python3 main.py
```
