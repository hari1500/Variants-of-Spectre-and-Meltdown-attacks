## Running the Files
```shell
$ make
$ ./spectrev1
```
