# Executing the code
Seperate README is added in each directory
