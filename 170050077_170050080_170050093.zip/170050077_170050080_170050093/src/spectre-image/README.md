## Running the Files
1. Encode the secret image that we have, example rgb
   ```shell
   $ cd encode_rgb
   $ python3 encode.py
   ```
   Input the image file details in the program.
   (Eg: secret_img.jpg)

2. Run spectre attack at project root dir
   ```shell
   $ make
   $ ./spectre
   ```
   The output is shown in 'spectre_output.txt'

3. Decode the spectre output
    ```shell
    $ cd decode_rgb
    $ python3 decode.py
    ```
    Input the necessary details in the program.
    (Eg: 80 80)

4. Apply Median filter on Resulting image to remove hot pixels
   ```shell
   $ cd median_filter
   $ python3 median.py
   ```
   Input the necessary details in the program.
    (Eg: 3)
