# Running Meltdown Exploit

## Disabling KAISER(PTI) and KASLR

Change boot options in the **grub** file

open grub file at **/etc/default/grub**

add extra options to **GRUB_CMDLINE_LINUX_DEFAULT** line

add kernel boot options  **kpti=off** to disable KPTI and **nokaslr** to disable KASLR

Update grub and reboot

    sudo update-grub
    sudo reboot

## Running Exploit to leak kernel symbols

We try to leak  **linux_banner** debug symbol present in kernel address space 

    chmod +x run.sh  
    sudo ./run.sh

Last line of output shows whether the data has been leaked successfully
