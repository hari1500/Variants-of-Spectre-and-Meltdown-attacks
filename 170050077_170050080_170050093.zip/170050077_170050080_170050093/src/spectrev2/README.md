## Running the Files
```shell
$ make
$ ./spectrev2
```
